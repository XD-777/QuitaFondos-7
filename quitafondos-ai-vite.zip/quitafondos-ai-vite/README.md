# Quitafondos AI (React + Vite)

Aplicación web de eliminación de fondo con IA en el navegador usando `@imgly/background-removal`.

## Requisitos
- Node.js 20.19+ o 22.12+ recomendado.
- npm.

## Instalación y ejecución

```bash
npm install
npm run dev
```

Abrí la URL local que muestra Vite (normalmente http://localhost:5173).

## Compilar para producción

```bash
npm run build
npm run preview
```

El resultado de producción queda en `dist/`.

## Notas importantes
- Las imágenes elegidas y el procesamiento se mantienen en el navegador. No se envían a un backend propio.
- En la primera ejecución, el navegador descarga los archivos del modelo desde la infraestructura CDN de IMG.LY; por eso se necesita conexión a Internet inicialmente. Después el navegador puede reutilizar la caché.
- La velocidad depende del dispositivo, memoria disponible y navegador. El modelo puede consumir varios cientos de MB entre descarga y memoria temporal.
- Los encabezados COOP/COEP están configurados en Vite dev y preview para habilitar escenarios que requieran aislamiento cross-origin. Si se publica en otro hosting, configurá esos encabezados allí también si tu entorno/modelo los necesita.
- El proyecto no incluye `node_modules` ni archivos de compilación.
- Revisá los términos/licencia vigentes de `@imgly/background-removal` antes de usar comercialmente el proyecto.
