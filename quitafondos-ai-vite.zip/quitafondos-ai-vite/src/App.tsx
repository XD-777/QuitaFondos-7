import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowDownToLine, ArrowLeftRight, Check, ImagePlus, LoaderCircle,
  LockKeyhole, RefreshCw, ShieldCheck, Sparkles, UploadCloud, WandSparkles
} from "lucide-react";
import confetti from "canvas-confetti";
import { removeBackground } from "@imgly/background-removal";

type Stage = "idle" | "loading" | "processing" | "done" | "error";
type BackgroundChoice = "transparent" | "white" | "black" | "red" | "blue" | "yellow" | "custom";

const backgrounds: { id: BackgroundChoice; label: string; color?: string }[] = [
  { id: "transparent", label: "Transparente" },
  { id: "white", label: "Blanco", color: "#ffffff" },
  { id: "black", label: "Negro", color: "#111111" },
  { id: "red", label: "Rojo", color: "#ef4444" },
  { id: "blue", label: "Azul", color: "#2563eb" },
  { id: "yellow", label: "Amarillo", color: "#facc15" },
  { id: "custom", label: "Personalizado" }
];

const sampleSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="720" height="900" viewBox="0 0 720 900">
<defs><linearGradient id="shirt" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#a78bfa"/><stop offset="1" stop-color="#5b21b6"/></linearGradient></defs>
<rect width="720" height="900" fill="#e9e5f4"/>
<ellipse cx="360" cy="835" rx="190" ry="30" fill="#c4bdd5"/>
<path d="M225 475 Q360 410 495 475 L560 850 L160 850Z" fill="url(#shirt)"/>
<path d="M270 470 Q360 530 450 470 L420 590 Q360 640 300 590Z" fill="#f0b995"/>
<ellipse cx="360" cy="300" rx="145" ry="175" fill="#f3c5a4"/>
<path d="M215 300 Q195 100 365 105 Q525 105 510 310 Q475 225 430 205 Q350 260 230 220Z" fill="#30263e"/>
<path d="M290 320 Q310 340 330 320 M390 320 Q410 340 430 320" fill="none" stroke="#30263e" stroke-width="12" stroke-linecap="round"/>
<path d="M330 395 Q360 415 390 395" fill="none" stroke="#a34e55" stroke-width="9" stroke-linecap="round"/>
<path d="M160 850 L560 850" stroke="#4c1d95" stroke-width="8"/>
</svg>`;

function fileFromBlob(blob: Blob, name: string) {
  return new File([blob], name, { type: blob.type || "image/png" });
}

export default function App() {
  const inputRef = useRef<HTMLInputElement>(null);
  const originalUrlRef = useRef<string | null>(null);
  const resultUrlRef = useRef<string | null>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [originalUrl, setOriginalUrl] = useState("");
  const [resultUrl, setResultUrl] = useState("");
  const [fileName, setFileName] = useState("imagen");
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [background, setBackground] = useState<BackgroundChoice>("transparent");
  const [customColor, setCustomColor] = useState("#8b5cf6");
  const [split, setSplit] = useState(50);
  const [dragging, setDragging] = useState(false);

  useEffect(() => () => {
    if (originalUrlRef.current) URL.revokeObjectURL(originalUrlRef.current);
    if (resultUrlRef.current) URL.revokeObjectURL(resultUrlRef.current);
  }, []);

  const reset = useCallback(() => {
    if (originalUrlRef.current) URL.revokeObjectURL(originalUrlRef.current);
    if (resultUrlRef.current) URL.revokeObjectURL(resultUrlRef.current);
    originalUrlRef.current = null;
    resultUrlRef.current = null;
    setOriginalUrl("");
    setResultUrl("");
    setStage("idle");
    setProgress(0);
    setStatus("");
    setError("");
    setBackground("transparent");
    setSplit(50);
    if (inputRef.current) inputRef.current.value = "";
  }, []);

  const processFile = useCallback(async (file: File) => {
    if (!file.type.startsWith("image/") || !["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
      setError("Formato no compatible. Elegí una imagen PNG, JPG o WEBP.");
      setStage("error");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setError("La imagen supera el límite recomendado de 20 MB.");
      setStage("error");
      return;
    }
    reset();
    const sourceUrl = URL.createObjectURL(file);
    originalUrlRef.current = sourceUrl;
    setOriginalUrl(sourceUrl);
    setFileName(file.name.replace(/\.[^.]+$/, "") || "imagen");
    setStage("loading");
    setProgress(2);
    setStatus("Preparando el motor de inteligencia artificial…");
    setError("");

    try {
      const result = await removeBackground(file, {
        model: "medium",
        output: { format: "image/png", quality: 1 },
        progress: (key: string, current: number, total: number) => {
          const percent = total > 0 ? Math.round((current / total) * 100) : 0;
          setProgress(Math.max(3, Math.min(99, percent)));
          if (/fetch|download|model/i.test(key)) {
            setStage("loading");
            setStatus("Descargando el modelo de IA (solo la primera vez)…");
          } else {
            setStage("processing");
            setStatus("La IA está detectando y separando el sujeto…");
          }
        }
      });
      const outputUrl = URL.createObjectURL(result);
      resultUrlRef.current = outputUrl;
      setResultUrl(outputUrl);
      setProgress(100);
      setStatus("¡Fondo eliminado correctamente!");
      setStage("done");
      confetti({ particleCount: 85, spread: 65, origin: { y: 0.72 }, colors: ["#8b5cf6", "#c4b5fd", "#6d28d9"] });
    } catch (err) {
      console.error(err);
      setStage("error");
      setError("No se pudo procesar esta imagen. Revisá tu conexión para descargar el modelo la primera vez e intentá con otra imagen.");
      setStatus("");
    }
  }, [reset]);

  const onSelected = (file?: File) => { if (file) void processFile(file); };

  const loadSample = async () => {
    try {
      const blob = new Blob([sampleSvg], { type: "image/svg+xml" });
      const img = new Image();
      const temp = URL.createObjectURL(blob);
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = 720; canvas.height = 900;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);
        canvas.toBlob((png) => {
          URL.revokeObjectURL(temp);
          if (png) onSelected(fileFromBlob(png, "ejemplo-retrato.png"));
        }, "image/png");
      };
      img.onerror = () => { URL.revokeObjectURL(temp); setError("No se pudo cargar el ejemplo."); };
      img.src = temp;
    } catch { setError("No se pudo preparar la imagen de ejemplo."); }
  };

  const getBackgroundColor = () => {
    if (background === "transparent") return null;
    if (background === "custom") return customColor;
    return backgrounds.find((item) => item.id === background)?.color ?? null;
  };

  const download = async () => {
    if (!resultUrl) return;
    const image = new Image();
    image.src = resultUrl;
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error("No se pudo cargar el resultado"));
    });
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const color = getBackgroundColor();
    if (color) {
      ctx.fillStyle = color;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    ctx.drawImage(image, 0, 0);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${fileName}-sin-fondo.png`;
      link.click();
      URL.revokeObjectURL(url);
    }, "image/png");
  };

  const isBusy = stage === "loading" || stage === "processing";

  return (
    <div className="min-h-screen bg-[#f8f7fc] text-[#201b31]">
      <header className="border-b border-violet-100/80 bg-white/85">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-600 text-white shadow-lg shadow-violet-200"><WandSparkles size={21} /></div>
            <div><div className="text-[17px] font-extrabold tracking-tight">Quitafondos <span className="text-violet-600">AI</span></div><div className="text-[10px] font-semibold uppercase tracking-[.19em] text-slate-400">Image studio</div></div>
          </div>
          <div className="hidden items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 sm:flex"><ShieldCheck size={14} /> Procesamiento privado en tu navegador</div>
          {originalUrl && <button onClick={reset} className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-600 transition hover:border-violet-200 hover:text-violet-700"><RefreshCw size={15} /> Nueva imagen</button>}
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 pb-16 pt-10 sm:px-8 sm:pt-14">
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-violet-100 bg-white px-3 py-1.5 text-xs font-bold text-violet-700 shadow-sm"><Sparkles size={13} /> EDICIÓN CON INTELIGENCIA ARTIFICIAL</div>
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-5xl">El fondo desaparece.<br /><span className="text-violet-600">Tu creatividad no.</span></h1>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-slate-500 sm:text-base">Quitá el fondo de tus imágenes en segundos. Sin subir tus archivos a servidores, sin marcas de agua y sin pagar por cada edición.</p>
        </div>

        {!originalUrl && !isBusy ? (
          <section className="mx-auto max-w-3xl">
            <div onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(e) => { e.preventDefault(); setDragging(false); onSelected(e.dataTransfer.files[0]); }}
              onClick={() => inputRef.current?.click()}
              className={`group cursor-pointer rounded-[28px] border-2 border-dashed bg-white px-6 py-14 text-center shadow-soft transition sm:px-12 ${dragging ? "border-violet-500 bg-violet-50" : "border-violet-200 hover:border-violet-400 hover:bg-violet-50/40"}`}>
              <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => onSelected(e.target.files?.[0])} />
              <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-violet-50 text-violet-600 transition group-hover:scale-105"><UploadCloud size={37} strokeWidth={1.6} /></div>
              <h2 className="text-xl font-bold">Arrastrá tu imagen aquí</h2>
              <p className="mt-2 text-sm text-slate-500">o hacé clic para explorar tus archivos</p>
              <button onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }} className="mt-7 inline-flex items-center gap-2 rounded-xl bg-violet-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-violet-200 transition hover:-translate-y-0.5 hover:bg-violet-700"><ImagePlus size={17} /> Elegir una imagen</button>
              <p className="mt-5 text-xs text-slate-400">PNG, JPG o WEBP · Máximo recomendado: 20 MB</p>
            </div>
            <div className="mt-6 flex flex-col items-center justify-center gap-3 text-center sm:flex-row">
              <span className="text-xs font-semibold text-slate-400">¿Querés probarlo primero?</span>
              <button onClick={() => void loadSample()} className="inline-flex items-center gap-2 text-sm font-bold text-violet-700 hover:text-violet-900"><Sparkles size={15} /> Probar con imagen de ejemplo</button>
            </div>
            {stage === "error" && <p className="mt-5 rounded-xl bg-red-50 p-3 text-center text-sm text-red-700">{error}</p>}
          </section>
        ) : (
          <section className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_310px]">
            <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-soft">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-5 py-4">
                <div><h2 className="font-bold">Vista previa</h2><p className="mt-0.5 max-w-[230px] truncate text-xs text-slate-400">{fileName}</p></div>
                {stage === "done" && <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700"><Check size={13} /> Fondo eliminado</span>}
              </div>
              <div className="relative flex min-h-[360px] items-center justify-center overflow-hidden bg-[#f2f0f7] p-4 sm:min-h-[520px]">
                {resultUrl ? (
                  <div className={`relative mx-auto max-h-[600px] w-full overflow-hidden rounded-xl ${background === "transparent" ? "checkerboard" : ""}`} style={{ maxWidth: "720px", backgroundColor: getBackgroundColor() ?? undefined }}>
                    <img src={resultUrl} alt="Imagen sin fondo" className="block max-h-[600px] w-full select-none object-contain" />
                    <div className="absolute inset-0 overflow-hidden" style={{ width: `${split}%` }}>
                      <img src={originalUrl} alt="Imagen original" className="absolute inset-0 h-full w-full max-h-[600px] object-contain" />
                    </div>
                    <div className="pointer-events-none absolute inset-y-0 z-10" style={{ left: `${split}%` }}>
                      <div className="absolute inset-y-0 w-0.5 -translate-x-1/2 bg-white shadow-[0_0_8px_rgba(0,0,0,.45)]" />
                      <div className="absolute left-0 top-1/2 flex h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-white bg-violet-600 text-white shadow-lg"><ArrowLeftRight size={17} /></div>
                    </div>
                    <input aria-label="Comparar imagen original y resultado" type="range" min="0" max="100" value={split} onChange={(e) => setSplit(Number(e.target.value))} className="range-slider absolute inset-0 z-20 h-full w-full opacity-0" />
                    <div className="pointer-events-none absolute bottom-3 left-3 rounded-md bg-black/55 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-white">Original</div>
                    <div className="pointer-events-none absolute bottom-3 right-3 rounded-md bg-violet-700/85 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-white">Sin fondo</div>
                  </div>
                ) : originalUrl ? <img src={originalUrl} alt="Imagen seleccionada" className="max-h-[600px] max-w-full rounded-xl object-contain" /> : null}
                {isBusy && <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/90 px-6 text-center backdrop-blur-sm">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-100 text-violet-700"><LoaderCircle className="animate-spin" size={28} /></div>
                  <h3 className="font-bold">{stage === "loading" ? "Preparando la IA" : "Quitando el fondo…"}</h3>
                  <p className="mt-2 max-w-sm text-sm text-slate-500">{status}</p>
                  <div className="mt-6 h-2 w-full max-w-xs overflow-hidden rounded-full bg-violet-100"><div className="progress-shimmer h-full rounded-full transition-all" style={{ width: `${progress}%` }} /></div>
                  <p className="mt-2 text-xs font-bold tabular-nums text-violet-700">{progress}%</p>
                </div>}
                {stage === "error" && <div className="absolute inset-x-5 bottom-5 rounded-xl border border-red-100 bg-white p-4 text-sm text-red-700 shadow-lg">{error}</div>}
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 px-5 py-3 text-xs text-slate-400"><span>Mové el control para comparar antes y después</span>{stage === "done" && <span className="font-semibold text-emerald-700">{status}</span>}</div>
            </div>

            <aside className="h-fit space-y-5 rounded-3xl border border-slate-200 bg-white p-5 shadow-soft">
              <div><div className="mb-1 flex items-center gap-2"><Sparkles size={17} className="text-violet-600" /><h3 className="font-bold">Fondo de imagen</h3></div><p className="text-xs leading-5 text-slate-500">Elegí cómo querés que se vea tu imagen final.</p></div>
              <div className="grid grid-cols-2 gap-2">
                {backgrounds.map((item) => <button key={item.id} disabled={stage !== "done"} onClick={() => setBackground(item.id)} className={`flex min-h-[70px] flex-col items-center justify-center gap-2 rounded-xl border text-xs font-semibold transition disabled:cursor-not-allowed disabled:opacity-40 ${background === item.id ? "border-violet-500 bg-violet-50 text-violet-700 ring-2 ring-violet-100" : "border-slate-200 text-slate-600 hover:border-violet-200"}`}>
                  {item.id === "transparent" ? <span className="checkerboard h-6 w-9 rounded border border-slate-200" /> : item.id === "custom" ? <input aria-label="Color personalizado" type="color" value={customColor} onChange={(e) => { setCustomColor(e.target.value); setBackground("custom"); }} onClick={(e) => e.stopPropagation()} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent" /> : <span className="h-6 w-9 rounded border border-black/5" style={{ backgroundColor: item.color }} />}
                  {item.label}
                </button>)}
              </div>
              <div className="rounded-xl bg-violet-50 p-3 text-xs leading-5 text-violet-800"><div className="mb-1 flex items-center gap-2 font-bold"><LockKeyhole size={14} /> Tus imágenes son privadas</div>El análisis y la exportación se realizan localmente en tu navegador. El modelo de IA se descarga una vez desde la infraestructura de IMG.LY.</div>
              <button disabled={stage !== "done"} onClick={() => void download()} className="flex w-full items-center justify-center gap-2 rounded-xl bg-violet-600 px-4 py-3.5 text-sm font-bold text-white shadow-lg shadow-violet-200 transition hover:-translate-y-0.5 hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0"><ArrowDownToLine size={18} /> Descargar PNG en alta calidad</button>
              <button onClick={() => inputRef.current?.click()} className="flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-600 transition hover:border-violet-300 hover:text-violet-700"><ImagePlus size={16} /> Subir nueva imagen</button>
              <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => onSelected(e.target.files?.[0])} />
              {stage === "error" && <button onClick={reset} className="flex w-full items-center justify-center gap-2 text-sm font-semibold text-red-600"><RefreshCw size={14} /> Volver a empezar</button>}
            </aside>
          </section>
        )}

        <div className="mx-auto mt-12 grid max-w-4xl gap-4 sm:grid-cols-3">
          {[{ icon: ShieldCheck, title: "Privacidad primero", desc: "Tus imágenes no se envían a nuestros servidores." }, { icon: Sparkles, title: "IA de precisión", desc: "Detección automática del sujeto y sus bordes." }, { icon: LockKeyhole, title: "Sin costo por imagen", desc: "No necesitás una API key ni una suscripción." }].map(({ icon: Icon, title, desc }) => <div key={title} className="flex items-start gap-3 rounded-2xl border border-slate-100 bg-white/70 p-4"><div className="rounded-xl bg-violet-50 p-2 text-violet-600"><Icon size={18} /></div><div><h3 className="text-sm font-bold">{title}</h3><p className="mt-1 text-xs leading-5 text-slate-500">{desc}</p></div></div>)}
        </div>
        <footer className="mt-12 text-center text-xs text-slate-400">Quitafondos AI · Procesamiento local en el navegador</footer>
      </main>
    </div>
  );
}